﻿% Paises que participaron en la primera guerra mundial
i_guerra_pais(rusia).
i_guerra_pais(francia).
i_guerra_pais(estados_unidos).
i_guerra_pais(austria).
i_guerra_pais(hungria).
i_guerra_pais(turquia).
i_guerra_pais(reino_unido).
i_guerra_pais(italia).
i_guerra_pais(japon).

% Paises que participaron en la segunda guerra mundial
ii_guerra_pais(rusia).
ii_guerra_pais(francia).
ii_guerra_pais(estados_unidos).
ii_guerra_pais(polonia).
ii_guerra_pais(reino_unido).
ii_guerra_pais(alemania).
ii_guerra_pais(japon).
ii_guerra_pais(italia).
ii_guerra_pais(china).

% Determinar si participo en ambas guerras mundiales
i_y_ii_guerras(P) :- i_guerra_pais(P), ii_guerra_pais(P).

% Determinar si participo SOLO en la primera guerra mundial
i_guerra_solo(P) :- i_guerra_pais(P), not(ii_guerra_pais(P)).

% Determinar si participo SOLO en la segunda guerra mundial
ii_guerra_solo(P) :- ii_guerra_pais(P), not(i_guerra_pais(P)).

% Preguntas
preguntas :-
    write('PARTICIPACION DE LOS PAISES EN LAS GUERRAS MUNDIALES: '), nl,
    write('Por favor ingrese el nombre de un país '), nl,
    read(P1),
    (
        (i_y_ii_guerras(P1) -> write(P1), write(' estuvo implicado en la I y II Guerra Mundial.'), nl);
        (i_guerra_solo(P1) -> write(P1), write(' estuvo implicado solamente en la I Guerra Mundial.'), nl);
        (ii_guerra_solo(P1) -> write(P1), write(' estuvo implicado solamente en la II Guerra Mundial.'), nl);
        write(P1), write(' no estuvo implicado ni en la I ni en la II Guerra Mundial.'), nl
    ).

% Iniciar el programa
inicio :- preguntas.

% Ejecutar el programa
:- inicio.
